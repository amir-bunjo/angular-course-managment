export class CourseModel {
  id: number;
  name: string;
  description: string;
  location: string;
}
